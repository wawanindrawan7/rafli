<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 mx-auto">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('users/edit')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" value="<?php echo e($data->id); ?>" name="id">

                        <div class="mb-3">
                            <label class="form-label">Nama</label>
                            <input type="text" value="<?php echo e($data->name); ?>" name="name" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" value="<?php echo e($data->email); ?>" name="email" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-control">
                                <option value="1" <?php echo e($data->role == 1 ? 'selected' : ''); ?>>Admin</option>
                                <option value="2" <?php echo e($data->role == 2 ? 'selected' : ''); ?>>Masyarakat NTB</option>
                                <option value="3" <?php echo e($data->role == 3 ? 'selected' : ''); ?>>Kementaan Pemprov NTB
                                </option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <input type="text" value="<?php echo e($data->alamat); ?>" name="alamat" class="form-control">
                        </div>

                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rafli/resources/views/user/edit.blade.php ENDPATH**/ ?>