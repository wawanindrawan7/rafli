<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 mx-auto">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <a href="<?php echo e(url('tanaman/create')); ?>" class="btn btn-primary">Tambah Data</a>
                    </div>
                    <hr />
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Gambar</th>
                                    <th>Nama</th>
                                    <th>Harga</th>
                                    <th width="10%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td> <?php echo e($item->nama); ?> </td>
                                        <td>
                                            <a href="<?php echo e(url('public/storage/gambar/' . $item->gambar)); ?>">
                                                <img width="80px"
                                                    src="<?php echo e(url('public/storage/gambar/' . $item->gambar)); ?>"
                                                    alt=""></a>
                                        </td>
                                        <td>Rp. <?php echo e(number_format($item->harga)); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('tanaman/edit?id=' . $item->id)); ?>"
                                                class="btn btn-warning m-1"><i class="bx bx-pencil"></i>
                                            </a>
                                            <a href="<?php echo e(url('tanaman/delete?id=' . $item->id)); ?>"
                                                class="btn btn-danger m-1"><i class="bx bx-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rafli/resources/views/tanaman/index.blade.php ENDPATH**/ ?>